// FILE: store/driverApi.js
// RTK Query — endpoints matching your existing backend routes
// ─────────────────────────────────────────────────────────────────────────

import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import * as SecureStore from "expo-secure-store";
 
const API_URL = process.env.EXPO_PUBLIC_API_URL ?? "http://192.168.1.100:3000";
 
export const driverApi = createApi({
  reducerPath: "driverApi",
  baseQuery: fetchBaseQuery({
    baseUrl: API_URL,
    prepareHeaders: async (headers, { getState }) => {
      const token = getState().auth.token
        ?? await SecureStore.getItemAsync("driver_token");
      if (token) headers.set("Authorization", `Bearer ${token}`);
      headers.set("Content-Type", "application/json");
      return headers;
    },
  }),
  tagTypes: ["Trip", "Alerts"],
  endpoints: (builder) => ({
 
    // POST /api/v1/auth/driver/login  { phone, pin }
    // Returns: { token, driver: { id, name, phone, truck } }
    login: builder.mutation({
      query: (body) => ({ url: "/api/v1/auth/driver/login", method: "POST", body }),
    }),
 
    // GET /api/v1/drivers/viewCurrentTripdetails/:id
    // Returns the driver's active/scheduled trip with stops
    getActiveTrip: builder.query({
      query: (driverId) => `/api/v1/drivers/viewCurrentTripdetails/${driverId}`,
      providesTags: ["Trip"],
    }),
 
    // POST /api/v1/driver/accept-trip  { trip_id }
    // Backend sets trip status → in_transit, truck → on_trip
    acceptTrip: builder.mutation({
      query: (body) => ({ url: "/api/v1/driver/accept-trip", method: "POST", body }),
      invalidatesTags: ["Trip"],
    }),
 
    // POST /api/v1/driver/confirm-stop  { stop_id, trip_id }
    confirmStop: builder.mutation({
      query: (body) => ({ url: "/api/v1/driver/confirm-stop", method: "POST", body }),
      invalidatesTags: ["Trip"],
    }),
 
    // POST /api/v1/driver/end-trip  { trip_id }
    endTrip: builder.mutation({
      query: (body) => ({ url: "/api/v1/driver/end-trip", method: "POST", body }),
      invalidatesTags: ["Trip"],
    }),
 
    // POST /api/v1/driver/emergency  { trip_id, lat, lng }
    sendEmergency: builder.mutation({
      query: (body) => ({ url: "/api/v1/driver/emergency", method: "POST", body }),
    }),
 
    // POST /api/v1/driver/report  { trip_id, issue_type, note }
    reportIssue: builder.mutation({
      query: (body) => ({ url: "/api/v1/driver/report", method: "POST", body }),
    }),
 
    // GET /api/v1/drivers/getDriverTripHistory/:id
    getTripHistory: builder.query({
      query: (driverId) => `/api/v1/drivers/getDriverTripHistory/${driverId}`,
    }),
  }),
});
 
export const {
  useLoginMutation,
  useGetActiveTripQuery,
  useAcceptTripMutation,
  useConfirmStopMutation,
  useEndTripMutation,
  useSendEmergencyMutation,
  useReportIssueMutation,
  useGetTripHistoryQuery,
} = driverApi;
