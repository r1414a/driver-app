// FILE: app/(tabs)/home.js
// Map screen — shows assigned trip card, accept button, then full live map
// Socket: emits get-location (first ping) + get-updated-location (every 10s)
// ─────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator, Animated, Modal, ScrollView,
  StyleSheet, Text, TouchableOpacity, View,
} from "react-native";
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from "react-native-maps";
import * as Location from "expo-location";
import * as KeepAwake from "expo-keep-awake";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { useDispatch, useSelector } from "react-redux";
import { setActiveTrip, setStops, setTruckPos, setSpeed, setNearStop, pushAlert, confirmStop } from "../../store/tripSlice";
import { clearAuth } from "../../store/authSlice";
import {
  useGetActiveTripQuery, useAcceptTripMutation,
  useSendEmergencyMutation, useEndTripMutation,
} from "../../store/driverApi";
import { getSocket } from "../../lib/socket";
import { THEME } from "../../constants/theme";
import { STRINGS } from "../../constants/i18n";
 
// Haversine distance in metres between two {lat,lng} points
function haversine(a, b) {
  const R = 6371000, toRad = d => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
  const x = Math.sin(dLat/2)**2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}
 
function interpolateRoute(coords, fraction) {
  if (!coords?.length) return null;
  if (fraction <= 0) return coords[0];
  if (fraction >= 1) return coords[coords.length - 1];
  const maxIdx = coords.length - 1;
  const idx    = Math.min(Math.floor(fraction * maxIdx), maxIdx - 1);
  const t      = fraction * maxIdx - idx;
  return {
    latitude:  coords[idx].latitude  + t * (coords[idx+1].latitude  - coords[idx].latitude),
    longitude: coords[idx].longitude + t * (coords[idx+1].longitude - coords[idx].longitude),
  };
}
 
// Animated truck marker component
function AnimatedTruck({ position }) {
  const scale = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scale, { toValue: 1.08, duration: 1200, useNativeDriver: true }),
        Animated.timing(scale, { toValue: 1,    duration: 1200, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return (
    <Marker coordinate={position} anchor={{ x: 0.5, y: 0.5 }}>
      <Animated.View style={[mS.truckMarker, { transform: [{ scale }] }]}>
        <Text style={{ fontSize: 22 }}>🚛</Text>
      </Animated.View>
    </Marker>
  );
}
 
export default function HomeScreen() {
  const insets   = useSafeAreaInsets();
  const dispatch = useDispatch();
  const driver   = useSelector(s => s.auth.driver);
  const token    = useSelector(s => s.auth.token);
  const lang     = useSelector(s => s.auth.lang ?? "en");
  const { stops, nearStopId, speed } = useSelector(s => s.trip);
  const s = STRINGS[lang];
 
  const { data: tripRaw, isLoading: tripLoading, refetch } =
    useGetActiveTripQuery(driver?.id, { skip: !driver?.id, pollingInterval: 30000 });
 
  const [acceptTrip,    { isLoading: accepting }]    = useAcceptTripMutation();
  const [sendEmergency]                              = useSendEmergencyMutation();
  const [endTrip]                                    = useEndTripMutation();
 
  const trip        = Array.isArray(tripRaw) ? tripRaw[0] : tripRaw;
  const tripId      = trip?.id ?? trip?.trip_id;
  const isScheduled = trip?.status === "scheduled";
  const isOnTrip    = trip?.status === "in_transit";
 
  const [userLoc, setUserLoc]         = useState(null);
  const [gpsStatus, setGpsStatus]     = useState("loading");
  const [routeFraction, setFraction]  = useState(0.0);
  const [showEmergency, setShowEmg]   = useState(false);
  const [emergencySent, setEmgSent]   = useState(false);
  const [showEndTrip, setShowEnd]     = useState(false);
  const [simSpeed, setSimSpeed]       = useState(0);
 
  const locationIntervalRef = useRef(null);
  const gpsSubRef           = useRef(null);
  const animIntervalRef     = useRef(null);
  const socketRef           = useRef(null);
  const lastPosRef          = useRef(null);
  const firstPingRef        = useRef(true);
 
  // Keep screen awake
  useEffect(() => {
    KeepAwake.activateKeepAwakeAsync();
    return () => KeepAwake.deactivateKeepAwake();
  }, []);
 
  // Seed stops from trip data
  useEffect(() => {
    if (!trip?.stops?.length) return;
    const mapped = trip.stops.map((st, i) => ({
      id:          st.id,
      order:       st.stop_order ?? i + 1,
      name:        st.store_name ?? st.name ?? `Stop ${i+1}`,
      address:     st.address ?? "",
      latitude:    parseFloat(st.latitude  ?? st.store_lat),
      longitude:   parseFloat(st.longitude ?? st.store_lng),
      etaTime:     st.eta ?? "—",
      status:      st.status === "completed" ? "completed" : "pending",
      geofenceRadius: parseInt(st.geofence_radius ?? 200),
      milestonePct:Math.round(((i + 1) / (trip.stops.length + 1)) * 100),
    }));
    dispatch(setStops(mapped));
    dispatch(setActiveTrip(trip));
  }, [trip?.id, trip?.stops?.length]);
 
  // GPS watcher
  useEffect(() => {
    let sub = null;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") { setGpsStatus("error"); return; }
      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 3000, distanceInterval: 5 },
        (pos) => {
          const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserLoc({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
          lastPosRef.current = loc;
          setGpsStatus("ok");
        }
      );
      gpsSubRef.current = sub;
    })();
    return () => { sub?.remove(); };
  }, []);
 
  // Socket + location streaming when on trip
  useEffect(() => {
    if (!isOnTrip || !tripId || !token) return;
 
    const socket = getSocket(token);
    socketRef.current = socket;
 
    socket.on("connect", () => {
      socket.emit("join-delivery", { deliveryId: tripId });
    });
 
    // Server broadcasts location-update back to all in room
    socket.on("location-update", ({ lat, lng }) => {
      dispatch(setTruckPos({ lat, lng }));
    });
 
    // Server broadcasts Alert when deviation/speeding/geofence
    socket.on("Alert", (data) => {
      dispatch(pushAlert({
        type:     "server_alert",
        severity: "high",
        message:  data.message,
        time:     new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
      }));
    });
 
    // Send location to backend every 10 seconds
    locationIntervalRef.current = setInterval(() => {
      const pos = lastPosRef.current;
      if (!pos) return;
 
      // First ping uses get-location (sets trip status to in_transit on backend)
      if (firstPingRef.current) {
        socket.emit("get-location", {
          deliveryId: tripId,
          lat: pos.lat,
          lng: pos.lng,
        });
        firstPingRef.current = false;
      } else {
        socket.emit("get-updated-location", {
          deliveryId: tripId,
          lat:   pos.lat,
          lng:   pos.lng,
          speed: simSpeed,
        });
      }
 
      // Near-store detection (local check, backup to server's geofence)
      stops.filter(st => st.status === "pending").forEach(stop => {
        const dist = haversine(pos, { lat: stop.latitude, lng: stop.longitude });
        if (dist < (stop.geofenceRadius ?? 200)) {
          dispatch(setNearStop(stop.id));
        }
      });
    }, 10000);
 
    // Animate truck on map (interpolate between socket position updates)
    animIntervalRef.current = setInterval(() => {
      setFraction(prev => Math.min(prev + 0.004, 0.95));
      setSimSpeed(prev => Math.max(0, prev + (Math.random() > 0.5 ? 3 : -3)));
      setSimSpeed(50 + Math.floor(Math.random() * 35));
    }, 2000);
 
    return () => {
      clearInterval(locationIntervalRef.current);
      clearInterval(animIntervalRef.current);
      socket.off("location-update");
      socket.off("Alert");
    };
  }, [isOnTrip, tripId, token]);
 
  const handleAcceptTrip = async () => {
    if (!tripId) return;
    try {
      await acceptTrip({ trip_id: tripId }).unwrap();
      firstPingRef.current = true;
      refetch();
    } catch (e) { console.error(e); }
  };
 
  const handleEmergency = async () => {
    setEmgSent(true);
    setShowEmg(false);
    const pos = lastPosRef.current;
    if (tripId && pos) {
      try { await sendEmergency({ trip_id: tripId, lat: pos.lat, lng: pos.lng }).unwrap(); }
      catch {}
    }
    dispatch(pushAlert({
      type: "emergency", severity: "high",
      message: "Emergency alert sent to DC operator.",
      time: new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
    }));
  };
 
  const handleEndTrip = async () => {
    setShowEnd(false);
    if (tripId) {
      try { await endTrip({ trip_id: tripId }).unwrap(); }
      catch {}
    }
    clearInterval(locationIntervalRef.current);
    clearInterval(animIntervalRef.current);
    socketRef.current?.disconnect();
    router.replace("/trip-complete");
  };
 
  // Build route coords: DC → stores in order
  const dcCoords = { latitude: parseFloat(trip?.dc_latitude ?? 18.6298), longitude: parseFloat(trip?.dc_longitude ?? 73.7997) };
  const routeCoords = trip ? [dcCoords, ...stops.map(st => ({ latitude: st.latitude, longitude: st.longitude }))] : [];
  const truckMapPos = routeCoords.length > 1 ? interpolateRoute(routeCoords, routeFraction) : dcCoords;
  const splitIdx    = Math.floor(routeFraction * Math.max(routeCoords.length - 1, 0));
  const donePath    = routeCoords.slice(0, splitIdx + 1);
  const restPath    = routeCoords.slice(splitIdx);
  const completedStops = stops.filter(st => st.status === "completed").length;
  const progressPct    = stops.length ? Math.round((completedStops / stops.length) * 100) : 0;
  const nearStop        = nearStopId ? stops.find(st => st.id === nearStopId) : null;
 
  // ── NO TRIP (loading or empty) ─────────────────────────────────────────
  if (tripLoading) {
    return (
      <View style={nS.root}>
        <View style={[nS.topBar, { paddingTop: insets.top + 8 }]}>
          <Text style={nS.topName}>{driver?.name ?? "Driver"}</Text>
        </View>
        <View style={nS.center}>
          <ActivityIndicator color={THEME.maroon} size="large" />
          <Text style={nS.centerTxt}>Loading your trip…</Text>
        </View>
      </View>
    );
  }
 
  // ── NO TRIP ASSIGNED ──────────────────────────────────────────────────
  if (!trip) {
    return (
      <View style={nS.root}>
        <View style={[nS.topBar, { paddingTop: insets.top + 8 }]}>
          <View style={nS.topLeft}>
            <View style={nS.avatar}><Text style={nS.avatarTxt}>{(driver?.name ?? "D")[0]}</Text></View>
            <View>
              <Text style={nS.topName}>{driver?.name ?? "Driver"}</Text>
              <Text style={nS.topSub}>{driver?.truck ?? "—"}</Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => { dispatch(clearAuth()); router.replace("/"); }} style={nS.logoutBtn}>
            <Text style={nS.logoutTxt}>Logout</Text>
          </TouchableOpacity>
        </View>
        <View style={nS.center}>
          <View style={nS.noTripCard}>
            <Text style={nS.noTripEmoji}>🚛</Text>
            <Text style={nS.noTripTitle}>{s.no_trip}</Text>
            <Text style={nS.noTripSub}>{s.no_trip_sub}</Text>
            <TouchableOpacity style={nS.refreshBtn} onPress={refetch}>
              <Text style={nS.refreshBtnTxt}>🔄 Refresh</Text>
            </TouchableOpacity>
          </View>
          // Status card
          <View style={nS.statusCard}>
            <View style={nS.statusRow}>
              <Text style={nS.statusLabel}>Driver</Text>
              <Text style={nS.statusValue}>{driver?.name}</Text>
            </View>
            <View style={[nS.statusRow, nS.statusBorder]}>
              <Text style={nS.statusLabel}>Truck</Text>
              <Text style={nS.statusValue}>{driver?.truck ?? "Not assigned"}</Text>
            </View>
            <View style={[nS.statusRow, nS.statusBorder]}>
              <Text style={nS.statusLabel}>GPS</Text>
              <Text style={[nS.statusValue, gpsStatus === "ok" ? { color: THEME.green600 } : { color: THEME.amber600 }]}>
                {gpsStatus === "ok" ? "● Active" : "● Getting…"}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  }
 
  // ── TRIP ASSIGNED (scheduled) — show accept card ───────────────────────
  if (isScheduled) {
    return (
      <View style={nS.root}>
        <View style={[nS.topBar, { paddingTop: insets.top + 8 }]}>
          <View style={nS.topLeft}>
            <View style={nS.avatar}><Text style={nS.avatarTxt}>{(driver?.name ?? "D")[0]}</Text></View>
            <View>
              <Text style={nS.topName}>{driver?.name}</Text>
              <Text style={nS.topSub}>{driver?.truck}</Text>
            </View>
          </View>
        </View>
 
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
          // Assignment banner
          <View style={aS.assignBanner}>
            <Text style={aS.assignBannerEmoji}>📦</Text>
            <View style={{ flex: 1 }}>
              <Text style={aS.assignBannerLabel}>NEW TRIP ASSIGNED</Text>
              <Text style={aS.assignBannerCode}>{trip.tracking_code ?? tripId?.slice(0,8)}</Text>
            </View>
            <View style={aS.statusPill}>
              <Text style={aS.statusPillTxt}>Scheduled</Text>
            </View>
          </View>
 
          // Trip summary card
          <View style={aS.card}>
            <Text style={aS.cardTitle}>Trip Summary</Text>
            {[
              ["🏭 From DC",    trip.dc_name ?? "Distribution Center"],
              ["🚛 Your truck", trip.truck_reg ?? driver?.truck ?? "—"],
              ["📦 Cargo",      trip.cargo ?? "Apparel"],
              ["🏪 Stops",      `${stops.length} store${stops.length !== 1 ? "s" : ""}`],
              ["📏 Distance",   trip.distance ? `${trip.distance} km` : "—"],
            ].map(([label, value]) => (
              <View key={label} style={aS.infoRow}>
                <Text style={aS.infoLabel}>{label}</Text>
                <Text style={aS.infoValue} numberOfLines={1}>{value}</Text>
              </View>
            ))}
          </View>
 
          // Stops preview
          {stops.length > 0 && (
            <View style={aS.card}>
              <Text style={aS.cardTitle}>Stops</Text>
              {stops.map((stop, i) => (
                <View key={stop.id} style={[aS.stopRow, i > 0 && aS.stopBorder]}>
                  <View style={aS.stopNum}><Text style={aS.stopNumTxt}>{i + 1}</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={aS.stopName} numberOfLines={1}>{stop.name}</Text>
                    <Text style={aS.stopAddr} numberOfLines={1}>{stop.address}</Text>
                  </View>
                </View>
              ))}
            </View>
          )}
 
          // Accept button
          <TouchableOpacity
            style={[aS.acceptBtn, accepting && { opacity: 0.7 }]}
            onPress={handleAcceptTrip}
            disabled={accepting}
            activeOpacity={0.88}
          >
            {accepting
              ? <ActivityIndicator color={THEME.white} />
              : <>
                  <Text style={aS.acceptBtnEmoji}>✓</Text>
                  <Text style={aS.acceptBtnTxt}>{s.accept_trip}</Text>
                </>
            }
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }
 
  // ── ACTIVE TRIP MAP ────────────────────────────────────────────────────
  return (
    <View style={mS.root}>
 
      // TOP BAR
      <View style={[mS.topBar, { paddingTop: insets.top + 8 }]}>
        <View style={mS.topLeft}>
          <View style={mS.topAvatar}><Text style={{ fontSize: 18 }}>🚛</Text></View>
          <View>
            <Text style={mS.topName}>{driver?.name ?? "Driver"}</Text>
            <Text style={mS.topCode}>{trip?.tracking_code ?? tripId?.slice(0,8)} · {driver?.truck}</Text>
          </View>
        </View>
        <TouchableOpacity onPress={() => setShowEnd(true)} style={mS.endBtn}>
          <Text style={mS.endBtnTxt}>{s.end_trip}</Text>
        </TouchableOpacity>
      </View>
 
      // EMERGENCY SENT BANNER
      {emergencySent && (
        <View style={mS.emergencyBanner}>
          <Text style={mS.emergencyBannerTxt}>🚨 {s.emergency_sent}</Text>
        </View>
      )}
 
      // NEAR STORE BANNER
      {nearStop && nearStop.status === "pending" && (
        <View style={mS.nearBanner}>
          <View style={{ flex: 1 }}>
            <Text style={mS.nearBannerLabel}>📍 {s.near_store}</Text>
            <Text style={mS.nearBannerStore} numberOfLines={1}>{nearStop.name}</Text>
          </View>
          <TouchableOpacity
            style={mS.nearConfirmBtn}
            onPress={() => {
              dispatch(confirmStop(nearStop.id));
              dispatch(setNearStop(null));
            }}
          >
            <Text style={mS.nearConfirmTxt}>✓ Confirm</Text>
          </TouchableOpacity>
        </View>
      )}
 
      // PROGRESS BAR
      <View style={mS.progressBar}>
        <View style={[mS.progressFill, { width: `${progressPct}%` }]} />
        {stops.map((stop) => (
          <View
            key={stop.id}
            style={[mS.milestoneDot,
              { left: `${stop.milestonePct}%` },
              stop.status === "completed" && mS.milestoneDotDone,
            ]}
          />
        ))}
      </View>
 
      // MAP
      <MapView
        style={mS.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={{
          latitude:  dcCoords.latitude,
          longitude: dcCoords.longitude,
          latitudeDelta: 0.18,
          longitudeDelta: 0.14,
        }}
        showsUserLocation={false}
        showsMyLocationButton={false}
      >
        // Completed route (green)
        {donePath.length > 1 && (
          <Polyline coordinates={donePath} strokeColor={THEME.green600} strokeWidth={5} />
        )}
        // Remaining route (blue dashed)
        {restPath.length > 1 && (
          <Polyline coordinates={restPath} strokeColor={THEME.blue500} strokeWidth={4} lineDashPattern={[10, 6]} />
        )}
 
        // DC marker
        <Marker coordinate={dcCoords} title="Distribution Center" description={trip?.dc_name}>
          <View style={mS.dcMarker}><Text style={{ fontSize: 18 }}>🏭</Text></View>
        </Marker>
 
        // Store markers
        {stops.map(stop => (
          <Marker
            key={stop.id}
            coordinate={{ latitude: stop.latitude, longitude: stop.longitude }}
            title={stop.name}
            description={stop.address}
          >
            <View style={[mS.storeMarker, stop.status === "completed" && mS.storeMarkerDone]}>
              <Text style={{ fontSize: 17 }}>{stop.status === "completed" ? "✅" : "🏪"}</Text>
            </View>
          </Marker>
        ))}
 
        // Animated truck
        {routeCoords.length > 1 && truckMapPos && (
          <AnimatedTruck position={truckMapPos} />
        )}
 
        // User location (driver's phone GPS)
        {userLoc && (
          <Marker coordinate={userLoc} anchor={{ x: 0.5, y: 0.5 }}>
            <View style={mS.userDot} />
          </Marker>
        )}
      </MapView>
 
      // OVERLAYS
      // Speed indicator
      <View style={[mS.speedBox, { top: insets.top + 80 }]}>
        <Text style={[mS.speedNum, simSpeed > 80 && { color: THEME.red600 }]}>{simSpeed}</Text>
        <Text style={mS.speedUnit}>km/h</Text>
        {simSpeed > 80 && <Text style={mS.speedWarn}>!</Text>}
      </View>
 
      // GPS status
      <View style={[mS.gpsPill, { top: insets.top + 80 }]}>
        <View style={[mS.gpsDot, { backgroundColor: gpsStatus === "ok" ? THEME.green500 : THEME.amber500 }]} />
        <Text style={mS.gpsTxt}>{gpsStatus === "ok" ? "GPS active" : "GPS…"}</Text>
      </View>
 
      // Stops progress chip
      <View style={[mS.progressChip, { top: insets.top + 80 }]}>
        <Text style={mS.progressChipTxt}>{completedStops}/{stops.length} stops · {progressPct}%</Text>
      </View>
 
      // EMERGENCY BUTTON
      <TouchableOpacity
        style={[mS.emergencyBtn, { bottom: insets.bottom + 18 }]}
        onPress={() => setShowEmg(true)}
        activeOpacity={0.9}
      >
        <Text style={mS.emergencyBtnTxt}>🚨  {s.emergency}</Text>
      </TouchableOpacity>
 
      // EMERGENCY MODAL
      <Modal visible={showEmergency} transparent animationType="slide">
        <View style={mS.modalBg}>
          <View style={mS.modalCard}>
            <View style={mS.modalIconWrap}>
              <Text style={{ fontSize: 44 }}>🚨</Text>
            </View>
            <Text style={mS.modalTitle}>{s.emergency_q}</Text>
            <Text style={mS.modalSub}>Your DC operator will be notified immediately with your location.</Text>
            <TouchableOpacity style={[mS.modalBtn, { backgroundColor: THEME.red600 }]} onPress={handleEmergency}>
              <Text style={mS.modalBtnTxt}>{s.emergency_yes}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[mS.modalBtn, { backgroundColor: THEME.slate100, marginTop: 8 }]} onPress={() => setShowEmg(false)}>
              <Text style={[mS.modalBtnTxt, { color: THEME.slate700 }]}>{s.emergency_cancel}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
 
      // END TRIP MODAL
      <Modal visible={showEndTrip} transparent animationType="slide">
        <View style={mS.modalBg}>
          <View style={mS.modalCard}>
            <View style={mS.modalIconWrap}>
              <Text style={{ fontSize: 44 }}>🏁</Text>
            </View>
            <Text style={mS.modalTitle}>{s.end_trip_q}</Text>
            <Text style={mS.modalSub}>All deliveries will be marked as complete.</Text>
            <TouchableOpacity style={[mS.modalBtn, { backgroundColor: THEME.maroon }]} onPress={handleEndTrip}>
              <Text style={mS.modalBtnTxt}>{s.end_trip_yes}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[mS.modalBtn, { backgroundColor: THEME.slate100, marginTop: 8 }]} onPress={() => setShowEnd(false)}>
              <Text style={[mS.modalBtnTxt, { color: THEME.slate700 }]}>{s.cancel}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}
 
// No-trip styles
const nS = StyleSheet.create({
  root:         { flex: 1, backgroundColor: THEME.slate50 },
  topBar:       { backgroundColor: THEME.maroon, paddingHorizontal: 18, paddingBottom: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  topLeft:      { flexDirection: "row", alignItems: "center", gap: 12 },
  avatar:       { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.25)", alignItems: "center", justifyContent: "center" },
  avatarTxt:    { color: THEME.white, fontSize: 16, fontWeight: "800" },
  topName:      { color: THEME.white, fontSize: 15, fontWeight: "800" },
  topSub:       { color: "rgba(255,255,255,0.65)", fontSize: 12, fontFamily: "monospace" },
  logoutBtn:    { backgroundColor: "rgba(255,255,255,0.2)", paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  logoutTxt:    { color: THEME.white, fontSize: 13, fontWeight: "600" },
  center:       { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 24 },
  centerTxt:    { color: THEME.slate500, fontSize: 14, marginTop: 14 },
  noTripCard:   { backgroundColor: THEME.white, borderRadius: 24, padding: 32, alignItems: "center", width: "100%", elevation: 4, shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 12, shadowOffset: { width: 0, height: 4 } },
  noTripEmoji:  { fontSize: 56, marginBottom: 16 },
  noTripTitle:  { fontSize: 20, fontWeight: "800", color: THEME.slate900, marginBottom: 8 },
  noTripSub:    { fontSize: 13, color: THEME.slate500, textAlign: "center", lineHeight: 20, marginBottom: 24 },
  refreshBtn:   { backgroundColor: THEME.slate100, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 12 },
  refreshBtnTxt:{ color: THEME.slate700, fontSize: 14, fontWeight: "600" },
  statusCard:   { marginTop: 20, backgroundColor: THEME.white, borderRadius: 18, width: "100%", overflow: "hidden", borderWidth: 1, borderColor: THEME.slate100 },
  statusRow:    { flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 18, paddingVertical: 13 },
  statusBorder: { borderTopWidth: 1, borderTopColor: THEME.slate100 },
  statusLabel:  { fontSize: 13, color: THEME.slate500 },
  statusValue:  { fontSize: 13, fontWeight: "700", color: THEME.slate800 },
});
 
// Accept trip styles
const aS = StyleSheet.create({
  assignBanner:    { flexDirection: "row", alignItems: "center", gap: 14, backgroundColor: "#fef9ec", borderRadius: 18, borderWidth: 1.5, borderColor: "#fde68a", padding: 18, marginBottom: 16 },
  assignBannerEmoji:{ fontSize: 32 },
  assignBannerLabel:{ fontSize: 10, fontWeight: "700", color: "#92400e", letterSpacing: 1.5 },
  assignBannerCode: { fontSize: 18, fontWeight: "900", color: THEME.slate900, fontFamily: "monospace", marginTop: 2 },
  statusPill:      { backgroundColor: THEME.slate100, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  statusPillTxt:   { fontSize: 11, fontWeight: "700", color: THEME.slate600 },
  card:            { backgroundColor: THEME.white, borderRadius: 18, padding: 18, marginBottom: 14, elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 8, shadowOffset: { width: 0, height: 2 } },
  cardTitle:       { fontSize: 13, fontWeight: "700", color: THEME.slate400, textTransform: "uppercase", letterSpacing: 1.2, marginBottom: 12 },
  infoRow:         { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: THEME.slate100 },
  infoLabel:       { fontSize: 14, color: THEME.slate500 },
  infoValue:       { fontSize: 14, fontWeight: "600", color: THEME.slate800, flex: 1, textAlign: "right", marginLeft: 16 },
  stopRow:         { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 11 },
  stopBorder:      { borderTopWidth: 1, borderTopColor: THEME.slate100 },
  stopNum:         { width: 28, height: 28, borderRadius: 14, backgroundColor: THEME.maroon, alignItems: "center", justifyContent: "center" },
  stopNumTxt:      { color: THEME.white, fontSize: 12, fontWeight: "800" },
  stopName:        { fontSize: 14, fontWeight: "600", color: THEME.slate800 },
  stopAddr:        { fontSize: 12, color: THEME.slate400, marginTop: 1 },
  acceptBtn:       { backgroundColor: THEME.maroon, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 18, borderRadius: 20, marginTop: 8, elevation: 6, shadowColor: THEME.maroon, shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: { width: 0, height: 6 } },
  acceptBtnEmoji:  { fontSize: 20, color: THEME.white },
  acceptBtnTxt:    { color: THEME.white, fontSize: 17, fontWeight: "800" },
});
 
// Map styles
const mS = StyleSheet.create({
  root:              { flex: 1, backgroundColor: THEME.slate900 },
  topBar:            { backgroundColor: THEME.maroon, paddingHorizontal: 16, paddingBottom: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  topLeft:           { flexDirection: "row", alignItems: "center", gap: 12 },
  topAvatar:         { width: 38, height: 38, borderRadius: 19, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  topName:           { color: THEME.white, fontSize: 15, fontWeight: "800" },
  topCode:           { color: "rgba(255,255,255,0.6)", fontSize: 11, fontFamily: "monospace" },
  endBtn:            { backgroundColor: "rgba(255,255,255,0.2)", paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  endBtnTxt:         { color: THEME.white, fontSize: 13, fontWeight: "600" },
  progressBar:       { height: 5, backgroundColor: THEME.slate100, position: "relative", overflow: "visible" },
  progressFill:      { position: "absolute", left: 0, top: 0, bottom: 0, backgroundColor: THEME.green500, borderRadius: 3 },
  milestoneDot:      { position: "absolute", top: -4, width: 13, height: 13, borderRadius: 7, backgroundColor: THEME.slate300, borderWidth: 2, borderColor: THEME.white, marginLeft: -6 },
  milestoneDotDone:  { backgroundColor: THEME.green600 },
  emergencyBanner:   { backgroundColor: THEME.red600, paddingVertical: 11, paddingHorizontal: 16, alignItems: "center" },
  emergencyBannerTxt:{ color: THEME.white, fontSize: 13, fontWeight: "700" },
  nearBanner:        { backgroundColor: THEME.green600, paddingVertical: 10, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", gap: 12 },
  nearBannerLabel:   { color: THEME.white, fontSize: 12, fontWeight: "700" },
  nearBannerStore:   { color: "rgba(255,255,255,0.85)", fontSize: 13, fontWeight: "600", marginTop: 1 },
  nearConfirmBtn:    { backgroundColor: THEME.white, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
  nearConfirmTxt:    { color: THEME.green700, fontSize: 13, fontWeight: "800" },
  map:               { flex: 1 },
  truckMarker:       { backgroundColor: THEME.maroon, width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: THEME.white, elevation: 10, shadowColor: THEME.maroon, shadowOpacity: 0.5, shadowRadius: 12, shadowOffset: { width: 0, height: 4 } },
  dcMarker:          { backgroundColor: "#1e3a8a", width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", borderWidth: 2.5, borderColor: THEME.white, elevation: 6 },
  storeMarker:       { backgroundColor: THEME.green700, width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", borderWidth: 2.5, borderColor: THEME.white, elevation: 4 },
  storeMarkerDone:   { backgroundColor: THEME.green500, opacity: 0.75 },
  userDot:           { width: 16, height: 16, borderRadius: 8, backgroundColor: THEME.sky500, borderWidth: 3, borderColor: THEME.white, elevation: 4 },
  speedBox:          { position: "absolute", right: 12, backgroundColor: THEME.white, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 10, alignItems: "center", elevation: 6, shadowColor: "#000", shadowOpacity: 0.15, shadowRadius: 8, shadowOffset: { width: 0, height: 3 } },
  speedNum:          { fontSize: 24, fontWeight: "900", color: THEME.slate900 },
  speedUnit:         { fontSize: 11, color: THEME.slate400 },
  speedWarn:         { fontSize: 12, fontWeight: "900", color: THEME.red600, marginTop: 1 },
  gpsPill:           { position: "absolute", left: 12, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, backgroundColor: THEME.white, elevation: 4 },
  gpsDot:            { width: 8, height: 8, borderRadius: 4 },
  gpsTxt:            { fontSize: 11, fontWeight: "600", color: THEME.slate700 },
  progressChip:      { position: "absolute", alignSelf: "center", left: "50%", marginLeft: -60, backgroundColor: THEME.white, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7, elevation: 4 },
  progressChipTxt:   { fontSize: 11, fontWeight: "700", color: THEME.slate700 },
  emergencyBtn:      { position: "absolute", left: 16, right: 16, backgroundColor: THEME.red600, paddingVertical: 17, borderRadius: 22, alignItems: "center", elevation: 10, shadowColor: THEME.red600, shadowOpacity: 0.45, shadowRadius: 14, shadowOffset: { width: 0, height: 6 } },
  emergencyBtnTxt:   { color: THEME.white, fontSize: 16, fontWeight: "900", letterSpacing: 0.5 },
  modalBg:           { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modalCard:         { backgroundColor: THEME.white, borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 28, paddingBottom: 44, alignItems: "center" },
  modalIconWrap:     { width: 80, height: 80, borderRadius: 40, backgroundColor: THEME.slate100, alignItems: "center", justifyContent: "center", marginBottom: 18 },
  modalTitle:        { fontSize: 20, fontWeight: "900", color: THEME.slate900, marginBottom: 8, textAlign: "center" },
  modalSub:          { fontSize: 13, color: THEME.slate500, marginBottom: 28, textAlign: "center", lineHeight: 20 },
  modalBtn:          { width: "100%", paddingVertical: 17, borderRadius: 18, alignItems: "center" },
  modalBtnTxt:       { color: THEME.white, fontSize: 16, fontWeight: "800" },
});